# 🌟 Най-лесни начини да публикуваш сайта си

## Метод 1: Vercel (Най-лесен)

### Стъпка 1: Отиди на Vercel
1. **Отиди на [vercel.com](https://vercel.com)**
2. **Кликни "Sign Up" с GitHub акаунт**

### Стъпка 2: Качи файловете
1. **Кликни "Add New Project"**
2. **Избери "Import Git Repository"**
3. **Ако нямаш GitHub - кликни "Deploy from template"**
4. **Drag & drop цялата папка с файловете**

## Метод 2: GitHub Pages (Безплатен)

### Стъпка 1: Създай GitHub акаунт
1. **[github.com](https://github.com) → Sign up**
2. **Потвърди имейла си**

### Стъпка 2: Създай repository
1. **Кликни зеленото "New"**
2. **Repository name:** `theta-healing-site`
3. **Public ✅**
4. **Create repository**

### Стъпка 3: Качи файловете
1. **"uploading an existing file"**
2. **Drag всички файлове наведнъж**
3. **Commit changes**

### Стъпка 4: Активирай Pages
1. **Settings → Pages**
2. **Source: Deploy from a branch**
3. **Branch: main**
4. **Folder: / (root)**
5. **Save**

## Метод 3: Surge.sh (Супер лесен)

### Стъпка 1: Инсталирай Surge
```bash
npm install -g surge
```

### Стъпка 2: Публикувай
```bash
cd dist
surge
```

### Стъпка 3: Следвай инструкциите
- Въведи имейл
- Избери домейн име
- Готово!

## Метод 4: Firebase Hosting

### Стъпка 1: Firebase Console
1. **[console.firebase.google.com](https://console.firebase.google.com)**
2. **Create a project**

### Стъпка 2: Hosting
1. **Hosting → Get started**
2. **Следвай инструкциите**

## 🎯 Кой метод да избереш?

- **Vercel** - най-лесен, автоматичен
- **GitHub Pages** - безплатен, стабилен
- **Surge** - най-бърз за еднократно качване
- **Firebase** - най-мощен, но по-сложен

## 🆘 Ако нищо не работи:

### План Б: Локален сървър
1. **Отвори терминал в папката с файловете**
2. **Напиши:** `python -m http.server 8000`
3. **Отвори:** `http://localhost:8000`
4. **Сподели екрана си с приятел да види сайта**

### План В: WeTransfer
1. **Zip-ни `dist` папката**
2. **Качи в [wetransfer.com](https://wetransfer.com)**
3. **Изпрати линка на хора да го свалят и отворят**

---

**Кой метод искаш да опитаме първо? 🚀**