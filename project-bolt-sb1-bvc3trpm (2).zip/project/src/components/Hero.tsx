import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-24 pb-12 bg-gradient-to-br from-blue-50 via-purple-50 via-teal-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            Открий силата на
            <span className="bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 bg-clip-text text-transparent"> вътрешната трансформация</span>
          </h1>
          
          <h2 className="text-2xl md:text-3xl font-semibold bg-gradient-to-r from-purple-700 to-blue-600 bg-clip-text text-transparent mb-8">
            Тета хийлинг медитации
          </h2>
          
          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto leading-relaxed">
            Потопи се в дълбоки медитативни състояния и открий своя истински потенциал. 
            Трансформирай живота си чрез силата на тета мозъчните вълни и вътрешното изцеление и освобождение.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <button className="group bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 hover:from-purple-700 hover:via-blue-600 hover:to-teal-700 text-white px-8 py-4 rounded-xl font-semibold transition-all duration-200 hover:shadow-2xl hover:scale-105 flex items-center">
              Започни Трансформацията
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Hero Image/Meditation Preview */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200 hover:shadow-3xl transition-shadow duration-300">
              <div className="bg-gradient-to-r from-purple-100 via-blue-100 to-teal-100 px-6 py-4 border-b border-gray-200">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 bg-purple-400 rounded-full"></div>
                  <div className="w-4 h-4 bg-blue-400 rounded-full"></div>
                  <div className="w-4 h-4 bg-teal-400 rounded-full"></div>
                  <div className="w-4 h-4 bg-indigo-400 rounded-full"></div>
                  <div className="w-4 h-4 bg-purple-500 rounded-full"></div>
                </div>
              </div>
              <div className="relative min-h-[400px] overflow-hidden">
                {/* Медитативна снимка с по-високо качество и скрита глава */}
                <img 
                  src="https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&fit=crop&crop=bottom" 
                  alt="Медитиращ човек в спокойна обстановка"
                  className="w-full h-full object-cover"
                />
                
                {/* Overlay с текст */}
                <div className="absolute inset-0 bg-gradient-to-t from-purple-900/60 via-transparent to-transparent flex items-end justify-center">
                  <div className="text-center p-8 text-white">
                    <h3 className="text-2xl font-bold mb-2">Твоето Медитативно Пространство</h3>
                    <p className="text-purple-100">Спокойствие, хармония и трансформация</p>
                    <div className="mt-6 flex justify-center space-x-3">
                      <div className="w-3 h-3 bg-purple-300 rounded-full animate-bounce"></div>
                      <div className="w-3 h-3 bg-blue-300 rounded-full animate-bounce delay-100"></div>
                      <div className="w-3 h-3 bg-teal-300 rounded-full animate-bounce delay-200"></div>
                      <div className="w-3 h-3 bg-indigo-300 rounded-full animate-bounce delay-300"></div>
                      <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce delay-400"></div>
                      <div className="w-3 h-3 bg-blue-400 rounded-full animate-bounce delay-500"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floating Elements - по-балансирани цветове */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-purple-400 via-blue-400 to-purple-500 rounded-full opacity-30 animate-pulse"></div>
            <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-gradient-to-br from-blue-400 via-teal-400 to-indigo-500 rounded-full opacity-25 animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 -right-12 w-16 h-16 bg-gradient-to-br from-teal-400 via-blue-400 to-purple-500 rounded-full opacity-20 animate-pulse delay-500"></div>
            <div className="absolute top-1/4 -left-8 w-20 h-20 bg-gradient-to-br from-indigo-400 via-purple-400 to-blue-500 rounded-full opacity-15 animate-pulse delay-700"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;