import React from 'react';
import { Check, Heart, Sparkles, Star } from 'lucide-react';

const plans = [
  {
    name: 'Пакет 1',
    subtitle: '„Завръщане към Себе си"',
    price: 55,
    icon: Heart,
    description: 'Освобождаване и свързване с душата',
    features: [
      'Три водени тета хийлинг медитации',
      'Освобождаване от стари травми',
      'Процес на прошка и изцеление',
      'Свързване с душата и мисията',
      'Възстановяване на вътрешния мир',
      'Пожизнен достъп до медитациите',
      'Аудио файлове за сваляне',
      'Подробни инструкции за практика'
    ],
    popular: false,
    gradient: 'from-purple-500 via-blue-500 to-purple-600',
    bgGradient: 'from-purple-50 via-blue-50 to-purple-100'
  },
  {
    name: 'Двата Пакета',
    subtitle: 'Пълна Трансформация',
    price: 88,
    originalPrice: 110,
    icon: Star,
    description: 'Най-добрата стойност за цялостна промяна',
    features: [
      'Всички 6 тета хийлинг медитации',
      'Пакет 1: „Завръщане към Себе си"',
      'Пакет 2: „Аз Съм Сила и Съзнание"',
      'Освобождаване + Манифестиране',
      'Пълна вътрешна трансформация',
      'Пожизнен достъп до всички медитации',
      'Подробни инструкции за практика',
      'Приоритетна поддръжка'
    ],
    popular: true,
    gradient: 'from-yellow-500 via-orange-500 to-amber-500',
    bgGradient: 'from-yellow-50 via-orange-50 to-amber-50',
    savings: '22 лв икономия'
  },
  {
    name: 'Пакет 2',
    subtitle: '„Аз Съм Сила и Съзнание"',
    price: 55,
    icon: Sparkles,
    description: 'Хармонизиране и манифестиране',
    features: [
      'Три мощни тета хийлинг медитации',
      'Хармонизиране на енергиите',
      'Повишаване на самоувереността',
      'Манифестиране от позицията „Аз Съм"',
      'Привличане на изобилие',
      'Пожизнен достъп до медитациите',
      'Аудио файлове за сваляне',
      'Техники за съзнателно сътворяване'
    ],
    popular: false,
    gradient: 'from-blue-500 via-teal-500 to-indigo-500',
    bgGradient: 'from-blue-50 via-teal-50 to-indigo-50'
  }
];

const Pricing = () => {
  return (
    <section id="pricing" className="py-24 bg-gradient-to-br from-purple-50 via-blue-50 to-teal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Избери своя път към
            <span className="bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 bg-clip-text text-transparent"> трансформацията</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Инвестирай в себе си и започни пътешествието към вътрешна свобода и хармония
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-3xl border-2 p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 ${
                plan.popular 
                  ? 'border-yellow-400 shadow-2xl scale-105 ring-4 ring-yellow-100 bg-gradient-to-br from-yellow-50 to-orange-50' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-amber-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                    🌟 Най-популярен избор
                  </span>
                </div>
              )}

              {plan.savings && (
                <div className="absolute -top-2 -right-2">
                  <span className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
                    {plan.savings}
                  </span>
                </div>
              )}

              <div className="text-center mb-8">
                <div className={`w-16 h-16 bg-gradient-to-br ${plan.gradient} rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg`}>
                  <plan.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <h4 className="text-lg font-semibold text-purple-700 mb-3">{plan.subtitle}</h4>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                
                <div className="flex items-baseline justify-center mb-2">
                  {plan.originalPrice && (
                    <span className="text-2xl text-gray-400 line-through mr-2">{plan.originalPrice} лв</span>
                  )}
                  <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                  <span className="text-gray-600 ml-2">лв</span>
                </div>
                
                {plan.popular && (
                  <p className="text-green-600 font-semibold text-sm">Спестяваш 22 лв!</p>
                )}
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700 text-sm leading-relaxed">{feature}</span>
                  </li>
                ))}
              </ul>

              <button className={`w-full py-4 px-6 rounded-xl font-bold text-lg transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-105 ${
                plan.popular
                  ? 'bg-gradient-to-r from-yellow-500 via-orange-500 to-amber-500 text-white hover:from-yellow-600 hover:via-orange-600 hover:to-amber-600'
                  : 'bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 text-white hover:from-purple-700 hover:via-blue-600 hover:to-teal-700'
              }`}>
                {plan.popular ? 'Избирам Двата Пакета' : `Избирам ${plan.name}`}
              </button>

              {plan.popular && (
                <p className="text-center text-xs text-gray-500 mt-3">
                  Най-добрата стойност за пари
                </p>
              )}
            </div>
          ))}
        </div>

        {/* Допълнителна информация */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-4xl mx-auto border-2 border-gradient-to-r from-purple-200 to-blue-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              ✨ Защо да инвестираш в тета хийлинг медитациите?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl mb-2">👥</div>
                <h4 className="font-semibold text-gray-900 mb-2">Доказани резултати</h4>
                <p className="text-gray-600 text-sm">100+ доволни клиенти вече преживяха положителни промени</p>
              </div>
              <div>
                <div className="text-3xl mb-2">⏰</div>
                <h4 className="font-semibold text-gray-900 mb-2">Бързи медитации</h4>
                <p className="text-gray-600 text-sm">Около 20 минути - лесно се вписват в ежедневието ти</p>
              </div>
              <div>
                <div className="text-3xl mb-2">♾️</div>
                <h4 className="font-semibold text-gray-900 mb-2">Без ограничение в броя на слушане</h4>
                <p className="text-gray-600 text-sm">Изпращам ви аудио файлове, които остават за вас завинаги</p>
              </div>
            </div>
            
            <div className="mt-8 bg-gradient-to-r from-purple-50 via-blue-50 to-teal-50 rounded-xl p-6 border border-purple-200">
              <div className="text-center">
                <div className="text-3xl mb-2">💝</div>
                <h4 className="font-semibold text-gray-900 mb-2">Инвестиция в себе си</h4>
                <p className="text-gray-600 text-sm max-w-2xl mx-auto">
                  Най-ценната инвестиция е в собственото ти развитие, изцеление и промяна на мисленето, 
                  което иначе се случва в безброй терапии и практики.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">
            Готов/а ли си да започнеш своето пътешествие към лекота, хармония и съзнателна промяна?
          </p>
          <p className="text-lg font-semibold bg-gradient-to-r from-purple-700 via-blue-600 to-teal-700 bg-clip-text text-transparent">
            📩 Пиши ми за достъп и започни трансформацията още днес!
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;