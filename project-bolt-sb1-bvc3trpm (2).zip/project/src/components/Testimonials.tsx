import React from 'react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Анонимен клиент',
    content: 'Супер медитация. Благодаря ти от сърце. След тежък ден се прибрах не само изморена но и ревяща. Много ми беше тежко и тъжно. Изслушах я и се отпуснах. Направо омекнах',
    rating: 5,
    highlight: true
  },
  {
    name: 'Клиент',
    content: 'Добро да е утрото, Кате! Даже е прекрасно! Преживяването ми беше ясното усещане в и през тялото за всяко ниво, през което минавах. Светлината попи и преминаваше през мен. Имах и осъзнаване за страха да бъда отхвърлена - това е, което ми пречи да се "покажа". Направи ми деня и месеца даже пълноценни и пълнокръвни с тази медитация!',
    rating: 5,
    highlight: false
  },
  {
    name: 'Клиент',
    content: 'Пак я направих и за моя изненада още в началото изскочи "Аз не съм сама!!!". А колко пъти съм казвала "сама се чувствам" и то доскоро... Нещо като историята на живота ми досега е това изречение. Какъв неочакван обрат ми донесе тази медитация! И днешното ми поведение определено е в синхран с нагласата "Аз не съм сама" 😊 Все едно ми започна отново деня! 😊 Как да не ви споделя! Дано и при всички ви има приятни изненади ❤️',
    rating: 5,
    highlight: true
  },
  {
    name: 'Ина Митарова',
    content: 'Кате, медитацията е вълшебна. Правя я за трети път. Отпуска ме, изпитвам състояние на блаженство на тялото и ума. Чувствам себе си. Сякаш през останалото време съм друга - в роля на майка, на приятелка, на колежка, а в медитацията усетих себе си. Как съм забравила какво е. И се откриваме отново. Благодаря ти от цялото си сърце.',
    rating: 5,
    highlight: false
  },
  {
    name: 'Теодор Колев',
    content: 'Браво! Много добра сесия! Напомня ми на Тета Лечение. Хубав ефект е, че доста бързо заспах! При това с лекота, някъде по средата. 😊 Интересен е факт е, че я направих вечерта преди заспиване и се получи пълноценен сън. Благодаря много!',
    rating: 5,
    highlight: false
  }
];

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-24 bg-gradient-to-br from-purple-50 via-blue-50 to-teal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Реални отзиви от 
            <span className="bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 bg-clip-text text-transparent"> доволни клиенти</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Вижте какво споделят хората, които вече преживяха трансформацията
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`group bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-2 ${
                testimonial.highlight 
                  ? 'border-purple-200 bg-gradient-to-br from-purple-50 via-blue-50 to-white' 
                  : 'border-gray-100 hover:border-purple-200'
              }`}
            >
              <div className="flex items-center mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <div className="relative mb-6">
                <Quote className="absolute -top-2 -left-2 w-6 h-6 text-purple-200" />
                <p className="text-gray-700 leading-relaxed pl-4 italic text-sm">
                  "{testimonial.content}"
                </p>
              </div>

              <div className="flex items-center">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 via-blue-500 to-teal-500 rounded-full flex items-center justify-center mr-3 shadow-lg">
                  <span className="text-white font-bold text-sm">
                    {testimonial.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">{testimonial.name}</h4>
                  <p className="text-xs text-purple-600">Клиент на тета хийлинг медитации</p>
                </div>
              </div>

              {testimonial.highlight && (
                <div className="mt-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg p-3 border border-purple-200">
                  <p className="text-purple-800 text-xs font-medium text-center">
                    ⭐ Препоръчан отзив
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Допълнителна секция с обобщение */}
        <div className="mt-16 text-center bg-white rounded-3xl p-8 shadow-xl border-2 border-gradient-to-r from-purple-200 to-blue-200">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Присъедини се към стотиците доволни клиенти
          </h3>
          <p className="text-gray-600 mb-6">
            Всеки ден получавам съобщения за положителните промени, които медитациите донасят в живота на хората.
          </p>
          <div className="flex justify-center items-center space-x-8 text-center">
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">100+</div>
              <div className="text-sm text-gray-600">Доволни клиенти</div>
            </div>
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">95%</div>
              <div className="text-sm text-gray-600">Положителни отзиви</div>
            </div>
            <div>
              <div className="text-3xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">24/7</div>
              <div className="text-sm text-gray-600">Достъп до медитациите</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;