import React from 'react';
import { Heart, Star, Sparkles, Moon } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-24 bg-gradient-to-br from-teal-50 via-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            За мен -
            <span className="bg-gradient-to-r from-teal-600 via-blue-500 to-purple-600 bg-clip-text text-transparent"> Екатерина Желязкова</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Специалист по работа с подсъзнанието, сертифициран по метода Тета Хийлинг
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Снимка и основна информация */}
          <div className="text-center lg:text-left">
            <div className="relative inline-block mb-8">
              <div className="w-64 h-64 mx-auto lg:mx-0 rounded-full overflow-hidden shadow-2xl border-4 border-white">
                <img 
                  src="/IMG_8802.jpeg" 
                  alt="Екатерина Желязкова - Тета хийлинг практик"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Декоративни елементи около снимката */}
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-purple-400 to-blue-500 rounded-full opacity-70 animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-br from-teal-400 to-purple-500 rounded-full opacity-60 animate-pulse delay-500"></div>
              <div className="absolute top-1/2 -left-6 w-8 h-8 bg-gradient-to-br from-blue-400 to-teal-500 rounded-full opacity-50 animate-pulse delay-1000"></div>
            </div>
          </div>

          {/* Текст за мен */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-purple-100">
              <div className="text-gray-700 leading-relaxed space-y-4">
                <p>
                  Аз съм <strong>Екатерина Желязкова</strong> — специалист по работа с подсъзнанието, сертифициран по метода Тета Хийлинг.
                </p>
                <p>
                  Работя с хора, които външно изглеждат силни, успешни и справящи се, но вътрешно често се усещат блокирани, претоварени, тревожни, самотни, изгубени...
                </p>
                <p>
                  Хора, които разбират, че вече не искат просто да „се справят", а да живеят осъзнато, свободно и в своята истина. Които искат да прекъснат цикъла на вътрешно напрежение, съмнение, тревожност и самосаботаж, и да изградят здрава, подкрепяща връзка първо със себе си, а после и с останалия свят през нов поглед.
                </p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100">
              <div className="flex items-center mb-4">
                <Heart className="w-6 h-6 text-blue-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Чувстваш ли се блокиран/а?</h3>
              </div>
              <div className="text-gray-700 leading-relaxed space-y-4">
                <p>
                  Чувстваш ли, че нещо в теб те спира — въпреки че на повърхността „всичко е наред"?
                </p>
                <p>
                  Може би вече си предприел/а действия, ходил/а си на терапия, опитвал/а си различни практики, но все още има нещо, което те дърпа назад. Онези натрапливи мисли още се появяват в главата ти - „не заслужавам", „ще се проваля", „няма да се справя", „страх ме е"...
                </p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-teal-100">
              <div className="flex items-center mb-4">
                <Sparkles className="w-6 h-6 text-teal-600 mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Подсъзнателни програми</h3>
              </div>
              <div className="text-gray-700 leading-relaxed space-y-4">
                <p>
                  Това не са просто мисли. А подсъзнателни програми, които ръководят изборите, реакциите и усещането ти за собствената стойност без дори да ги осъзнаваш. Някои от тях дори не са твои, а са наследени от семейството, рода, колективната памет.
                </p>
                <p>
                  В моята практика не давам бързи съвети. А помагам целенасочено да се стигне до корена на проблема – там, където подсъзнанието е „заключило"/запаметило старите убеждения или програми.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Какво е Тета хийлинг */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 rounded-3xl p-12 text-white shadow-2xl">
            <div className="flex items-center justify-center mb-6">
              <Moon className="w-12 h-12 mr-4" />
              <h3 className="text-3xl font-bold">Какво е Тета хийлинг?</h3>
            </div>
            
            <div className="max-w-4xl mx-auto space-y-6 text-lg leading-relaxed">
              <p>
                Тета Хийлинг е метод, с който работим в дълбоко релаксирано състояние на ума (тета вълни), за да открием и да пренапишем това, което вече не ти служи. Да го заменим със състояние на яснота, вътрешна сила и свобода. Да изберем и инсталираме нови програми, които да те подкрепят.
              </p>
              <p className="text-blue-100 font-semibold">
                Защото именно тези програми оформят мислите, изборите, действията – и съответно и реалността ни днес.
              </p>
            </div>
          </div>
        </div>

        {/* Моята практика */}
        <div className="mt-16 bg-white rounded-3xl p-12 shadow-xl border-2 border-gradient-to-r from-purple-200 to-teal-200">
          <div className="text-center max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              🌟 Моята практика
            </h3>
            <div className="text-lg text-gray-700 leading-relaxed space-y-4">
              <p>
                Работя онлайн и лично /във Варна/ с индивидуални сесии и в програми по теми като:
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-8">
                <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-xl p-4 border border-purple-200">
                  <span className="text-purple-700 font-medium">паник атаки</span>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl p-4 border border-blue-200">
                  <span className="text-blue-700 font-medium">страх от провал</span>
                </div>
                <div className="bg-gradient-to-br from-teal-100 to-purple-100 rounded-xl p-4 border border-teal-200">
                  <span className="text-teal-700 font-medium">тревожност</span>
                </div>
                <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-xl p-4 border border-purple-200">
                  <span className="text-purple-700 font-medium">липса на увереност</span>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl p-4 border border-blue-200">
                  <span className="text-blue-700 font-medium">емоционални зависимости</span>
                </div>
                <div className="bg-gradient-to-br from-teal-100 to-purple-100 rounded-xl p-4 border border-teal-200">
                  <span className="text-teal-700 font-medium">самосаботаж</span>
                </div>
                <div className="bg-gradient-to-br from-purple-100 to-blue-100 rounded-xl p-4 border border-purple-200">
                  <span className="text-purple-700 font-medium">вътрешно напрежение</span>
                </div>
                <div className="bg-gradient-to-br from-blue-100 to-teal-100 rounded-xl p-4 border border-blue-200">
                  <span className="text-blue-700 font-medium">и др.</span>
                </div>
              </div>
              <p className="font-semibold bg-gradient-to-r from-purple-700 via-blue-600 to-teal-700 bg-clip-text text-transparent">
                Ако усещаш, че е време да спреш да се бориш със себе си и да започнеш да живееш по начин, който е в синхрон с теб – пиши ми. Ще ти разкажа как можем да работим заедно.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;