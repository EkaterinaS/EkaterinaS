import React from 'react';
import { Heart, Sparkles, Star, Moon, Sun, Compass } from 'lucide-react';

const Features = () => {
  return (
    <section id="features" className="py-24 bg-gradient-to-br from-purple-50 via-blue-50 to-teal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Въведение */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-8 leading-tight">
            Чувстваш ли, че носиш
            <span className="bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 bg-clip-text text-transparent"> тежест от миналото?</span>
          </h2>
          
          <div className="max-w-4xl mx-auto space-y-6 text-lg text-gray-700 leading-relaxed">
            <p>
              Бориш ли се с неувереност, вътрешен хаос или усещане за загубена посока?
            </p>
            <p className="text-xl font-semibold bg-gradient-to-r from-purple-700 via-blue-600 to-teal-700 bg-clip-text text-transparent">
              Време е да спреш да се въртиш в кръг и да започнеш пътя към себе си и живота, който заслужаваш!
            </p>
            <p>
              Представям ти два специално разработени пакета медитации, които те водят по пътя на освобождаване, себепознание, хармонизиране и съзнателно проявление:
            </p>
          </div>
        </div>

        {/* Двата пакета */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Пакет 1 */}
          <div className="group bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 via-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">ПАКЕТ 1</h3>
              <h4 className="text-xl font-semibold bg-gradient-to-r from-purple-700 to-blue-600 bg-clip-text text-transparent mb-4">„Завръщане към Себе си"</h4>
              <p className="text-gray-600 font-medium">освобождаване и свързване с душата</p>
            </div>

            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Тези три медитации те водят през процес на освобождаване на стари травми, прошка и намиране на своята същност и мисия.
              </p>
              <p>
                <strong className="text-purple-700">Целта:</strong> да изчистиш тежестите от миналото, да възстановиш вътрешния мир и да се свържеш с истинското си Аз.
              </p>
              <p>
                <strong className="text-purple-700">Резултатът:</strong> повече лекота, яснота, вътрешна свобода и мир, които ти дават стабилна основа за личен растеж.
              </p>
              <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-4 rounded-xl mt-6 border border-purple-200">
                <p className="text-purple-800 font-medium">
                  Това е пътят, по който оставяш товара на миналото — спомени, травми, очаквания и огорчения, които вече не ти служат.
                </p>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap gap-2">
              <span className="bg-gradient-to-r from-purple-200 to-blue-200 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">Прошка</span>
              <span className="bg-gradient-to-r from-purple-200 to-blue-200 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">Свързване с душата</span>
              <span className="bg-gradient-to-r from-purple-200 to-blue-200 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">Мисия</span>
            </div>
          </div>

          {/* Пакет 2 */}
          <div className="group bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-teal-50">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 via-teal-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                <Sparkles className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">ПАКЕТ 2</h3>
              <h4 className="text-xl font-semibold bg-gradient-to-r from-blue-700 to-teal-600 bg-clip-text text-transparent mb-4">„Аз Съм Сила и Съзнание"</h4>
              <p className="text-gray-600 font-medium">хармонизиране и манифестиране/проявление</p>
            </div>

            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Три мощни медитации за хармонизиране на енергиите, повишаване на самоувереността и манифестиране на желанията ти от позицията на „Аз Съм".
              </p>
              <p>
                <strong className="text-blue-700">Целта:</strong> да настроиш вибрацията си за привличане на желаното и да утвърдиш своята стойност и сила.
              </p>
              <p>
                <strong className="text-blue-700">Резултатът:</strong> повече изобилие, увереност и съзнателно сътворяване.
              </p>
              <div className="bg-gradient-to-r from-blue-100 to-teal-100 p-4 rounded-xl mt-6 border border-blue-200">
                <p className="text-blue-800 font-medium">
                  Не защото трябва да „доказваш" нещо – а защото си достатъчен/а просто така.
                </p>
              </div>
            </div>

            <div className="mt-8 flex flex-wrap gap-2">
              <span className="bg-gradient-to-r from-blue-200 to-teal-200 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">Хармонизиране</span>
              <span className="bg-gradient-to-r from-blue-200 to-teal-200 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">Манифестиране</span>
              <span className="bg-gradient-to-r from-blue-200 to-teal-200 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">Аз Съм</span>
            </div>
          </div>
        </div>

        {/* Защо да избереш тези медитации */}
        <div className="bg-white rounded-3xl p-8 shadow-xl mb-16 border-2 border-gradient-to-r from-purple-200 to-blue-200">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-8">
            🔹 Защо да избереш тези медитации?
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 via-teal-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="w-8 h-8 text-white" />
              </div>
              <p className="text-gray-700 leading-relaxed">
                Водени са от <strong>Тета Хийлинг техники</strong>, доказали се като мощен инструмент за трансформация
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Compass className="w-8 h-8 text-white" />
              </div>
              <p className="text-gray-700 leading-relaxed">
                Подходящи са за всички, които искат да се свържат <strong>по-дълбоко със себе си</strong> и своята вътрешна сила
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 via-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Moon className="w-8 h-8 text-white" />
              </div>
              <p className="text-gray-700 leading-relaxed">
                <strong>Лесни за изпълнение</strong>, с ясни фокуси и резултати, които се усещат още след първите сесии
              </p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-purple-600 via-blue-500 to-teal-600 rounded-3xl p-12 text-white shadow-2xl">
          <h3 className="text-3xl font-bold mb-6">
            ✨ Готов/а ли си да започнеш своето пътешествие към лекота, хармония и съзнателна промяна? ✨
          </h3>
          
          <div className="space-y-4 mb-8 text-lg">
            <p>💌 Поръчай единия или двата пакета. Позволи си време за теб – не като бягство, а като завръщане.</p>
            <p>📩 Пиши ми за достъп.</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="bg-white text-purple-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-purple-50 transition-all duration-200 hover:shadow-lg hover:scale-105">
              Искам Пакет 1
            </button>
            <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-50 transition-all duration-200 hover:shadow-lg hover:scale-105">
              Искам Пакет 2
            </button>
            <button className="bg-gradient-to-r from-yellow-400 via-orange-400 to-amber-500 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-yellow-500 hover:via-orange-500 hover:to-amber-600 transition-all duration-200 hover:shadow-lg hover:scale-105">
              Искам И Двата Пакета
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;