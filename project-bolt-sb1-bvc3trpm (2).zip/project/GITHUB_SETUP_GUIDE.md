# 🚀 GitHub Setup Ръководство за Theta Healing Сайт

## Стъпка 1: Създаване на GitHub акаунт

1. **Отидете на [github.com](https://github.com)**
2. **Кликнете "Sign up"** (горе вдясно)
3. **Попълнете данните:**
   - Username: `ekaterina-zhelyazkova` (или каквото искате)
   - Email: вашият имейл
   - Password: сигурна парола
4. **Потвърдете имейла си**

## Стъпка 2: Създаване на Repository

1. **След като влезете в GitHub, кликнете зеленото "New" бутонче** (горе вляво)
2. **Попълнете формата:**
   - Repository name: `theta-healing-meditations`
   - Description: `Тета хийлинг медитации - уебсайт на Екатерина Желязкова`
   - ✅ Public (оставете отметнато)
   - ❌ Add a README file (НЕ отмествайте)
   - ❌ Add .gitignore (НЕ отмествайте)
   - ❌ Choose a license (НЕ отмествайте)
3. **Кликнете "Create repository"**

## Стъпка 3: Upload на файловете

1. **В новото repository ще видите празна страница**
2. **Кликнете "uploading an existing file"** (в средата на страницата)
3. **Drag & Drop всички файлове от ZIP-а:**
   - Можете да селектирате всички файлове наведнъж
   - Или да ги влачите група по група
4. **Изчакайте да се качат всички файлове**
5. **В полето "Commit changes" напишете:**
   ```
   Първоначално качване на Theta Healing уебсайт
   ```
6. **Кликнете "Commit changes"**

## Стъпка 4: Свързване с Netlify

1. **Отидете обратно в [Netlify](https://netlify.com)**
2. **Кликнете "Add new site" → "Import an existing project"**
3. **Изберете "Deploy with GitHub"**
4. **Ако се появи прозорец за разрешения:**
   - Кликнете "Authorize Netlify"
   - Въведете GitHub паролата си ако се изисква
5. **Изберете вашето repository** `theta-healing-meditations`
6. **Build settings (ще се попълнят автоматично):**
   - Build command: `npm run build`
   - Publish directory: `dist`
   - ✅ Оставете както са
7. **Кликнете "Deploy site"**

## Стъпка 5: Изчакване на Deploy

1. **Netlify ще започне да build-ва сайта** (2-3 минути)
2. **Ще видите статус "Site deploy in progress"**
3. **Когато приключи, ще получите линк като:**
   ```
   https://amazing-name-123456.netlify.app
   ```

## 🎉 Готово!

Вашият сайт вече е онлайн! Всяка промяна, която направите в GitHub, автоматично ще се публикува в Netlify.

## 📝 Полезни съвети:

- **Custom Domain:** В Netlify можете да добавите собствен домейн
- **Промени:** За промени в сайта, редактирайте файловете в GitHub
- **Backup:** Кодът ви е винаги запазен в GitHub

## 🆘 Ако имате проблеми:

1. **Проверете дали всички файлове са качени в GitHub**
2. **Уверете се, че Build command е `npm run build`**
3. **Проверете дали Publish directory е `dist`**

---

**Готови ли сте да започнете? Започнете от Стъпка 1! 🚀**